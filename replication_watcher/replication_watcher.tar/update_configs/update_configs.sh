#/usr/local/bin/bash -

#  update_configs.sh script.
#  This script should be run either by replication_watcher.sh or manually bu a user
#  in order to change the IP-address of the Postgresql database in some configuration files.
#  It needs to be done after a failover, because all programs that use Postgres dabase will have 
#  old (not relevant) ip-address for PostgreSQL
#
#  You should provide line number in configuration file where ip_address is located.
# Note, that if this script could not find any ip_address there, it will search 5 lines up and
# down from the given line number. If it finds only one ip_address entry, it will change it for 
# the new one, but also will write to syslog, so that you can correct your line number later.
# If no ip_addresses is found, it will write to syslog an error.
# Note, that all configuration file will be backed up before change, so that you can restore it
# in case of some failure. You need to delete them later manually, 
# because this script deletes them only if the amount is greater than 10 
# (to prevent from log overgrowing).
#

#
#  The list of files that need changes should be placed in one file. The format should be:
#  config_file_with_old_pgsql_address:number_of_line_in_file:path_to_file_to_restart
#  and all such enries must be separated by a new line.
# 
#  path_to_file_to_restart - is an optional parameter.

#
#  The file containing a list of configs should be passed with -f command key.
#

# Usage: update_configs.sh -f list_of_configs_to_update -a file_with_Postgres_ip_address

CURPATH=`echo "$0" | awk -F/ 'BEGIN { OFS="/"  } { $NF = ""; print; }'`
ERR_MSG=""
IP_ADDRESS_F=""
LIST_F=""

function show_usage() {
echo "Usage: update_configs.sh -f list_file -a master_ip_address_file"
echo ""
}


if [[ $# -lt 1 ]];
then
    logger -s "update_configs.sh error: No parameters given."
fi


while getopts f:a: option
do
 case "${option}"
 in
                a) IP_ADDRESS_F=${OPTARG};;
                f) LIST_F=${OPTARG};;
                h) show_usage ;
                   exit 0 ;;
 esac
done

# Checking given parameters:
if [[ ! -f ${IP_ADDRESS_F} ]];
then
   logger -s "update_configs.sh error: Inappropriate file containing IP-address."
   exit 1
fi
if [[ ! -s ${IP_ADDRESS_F} ]];
then
   logger -s "update_configs.sh error: empty file containing IP-address."
   exit 1
fi
if [[ ! -f ${LIST_F} ]];
then
   logger -s "update_configs.sh error: Inappropriate file containing list of configs."
   exit 1
fi
if [[ ! -s ${LIST_F} ]];
then
   logger -s "update_configs.sh error: empty file containing list of configs."
   exit 1
fi

#  Parsing  file:
while read line           
do
  CONFIG_F=`echo ${line} | awk -F ':' '{print $1;}'`
  LINE_NUM=`echo ${line} | awk -F ':' '{print $2;}'`
  SERVICE=`echo ${line} | awk -F ':' '{print $3;}'`
  # Check that values in the line are correct. If not - read another line.
  if [[ ! -f ${CONFIG_F} ]];
  then
      logger -s "update_configs.sh error: Configuration file ${CONFIG_F} not found."
      continue
  fi
  if [[ -z "${LINE_NUM}" ]];
  then
      logger -s "update_configs.sh error: Line number for ${CONFIG_F} not presented."
      continue
  fi
  if ! [[ "${LINE_NUM}" =~ ^[0-9]+$ ]] ; then
      logger -s "update_configs.sh error: Line number for ${CONFIG_F} is not a number."
      continue
  fi
  
  today=`date +"%d%m_%H%M"`
  # Now, backup config-file:
  if [[ -f ${CONFIG_F}".backup.""${today}" ]];
  then
       logger -s "update_configs.sh error: Backup for ${CONFIG_F} already exists. Dont want to overwrite."
       continue
  fi
  cp ${CONFIG_F} ${CONFIG_F}".backup.""${today}" &>/dev/null
  if [[ $? -ne 0 ]];
  then
     logger -s "update_configs.sh error: Unable to backup for ${CONFIG_F}."
     continue 
  fi
  # Now read config file and find an IP-address:
  old_ip="0"
  line_to_search=${LINE_NUM}
  offset=0
  
  while [[ "${old_ip}" = "0" ]];
  do
    if [[ ${offset} -eq -6 ]];
    then
      break;
    fi
    line_to_search=`echo "${LINE_NUM} + ${offset}" | bc`
    old_ip=`cat ${CONFIG_F} | awk '{if(NR=="'${line_to_search}'"){ if (match($0,"(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)") != 0){ print substr($0,RSTART,RLENGTH); exit; } else {print 0; exit;} }}'`    
    if [[ ${offset} -ge 0 ]];
    then
      offset=`echo "$offset * (-1)" | bc`
      offset=`echo "$offset - 1" | bc`
    else
      offset=`echo "$offset * (-1)" | bc`
    fi
  done
  
  if [[ "${old_ip}" = "0" ]];
  then
     logger -s "update_configs.sh error: No ip-address found in ${CONFIG_F}."
     continue 
  fi
  
  # check IP-address in IP_ADDR_F:
  IP_ADDR=`cat ${IP_ADDRESS_F} | awk '{if(NR==1){ if (match($0,"(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)") != 0){ print substr($0,RSTART,RLENGTH); exit; } else {print 0; exit;} }}'`
  if [[ "${IP_ADDR}" = "0" ]];
  then
     logger -s "update_configs.sh error: No valid ip-address found in ${IP_ADDRESS_F}."
     continue
  fi
  
  # Make changes in CONFIG_F:   # ATTENTION: SED DOESN't WORK HERE!!!!!!!
  sed -E ''"${line_to_search}"' s:(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?):'"${IP_ADDR}"':' <${CONFIG_F} >${CONFIG_F}".sedtmp"
  if [[ $? -eq 0 ]];
  then
     logger -s "update_configs.sh successfully changed ip from ${old_ip} to ${IP_ADDR} in ${CONFIG_F} line ${line_to_search}."
  fi
  cat ${CONFIG_F}".sedtmp" >${CONFIG_F}
  rm ${CONFIG_F}".sedtmp"
  
  # Reload given service if exist:
  if [[ ! -z "${SERVICE}" ]];
  then
      if [[ ! -f ${SERVICE} ]];
      then
         logger -s "update_configs.sh error: file ${SERVICE} does not exist. Reload it manually."
         continue 
      else
         ${SERVICE} reload &>/dev/null ||\
         logger -s "update_configs.sh error: Error while trying to reload ${SERVICE}. Try to restart it manually."
      fi
  fi

done <"${LIST_F:?'Sorry no file was found. Aborting.'}"